      --------------------------------------------------------
              Borland VCL50.BPL Runtime Package README
      --------------------------------------------------------
             Copyright (c) 1997-1999 Inprise Corporation


------------------------
HOW TO USE THIS DOCUMENT
------------------------

To view Readme.txt on screen in Notepad, maximize the Notepad window.

To print Readme.txt, open it in Notepad or another word processor, 
then use the Print command on the File menu.


--------
CONTENTS
--------

INSTALLATION


INSTALLATION
============

Copy VCL50.BPL to your Windows\System folder (Winnt\system32 in Windows NT or Windows 2000).